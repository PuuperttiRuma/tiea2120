// data-muuttuja sisältää kaiken tarvittavan ja on rakenteeltaan lähes samankaltainen kuin viikkotehtävässä 2
// Rastileimaukset on siirretty tupa-rakenteesta suoraan jokaisen joukkueen yhteyteen
//
// voit tutkia tarkemmin käsiteltävää tietorakennetta konsolin kautta 
// tai json-editorin kautta osoitteessa http://jsoneditoronline.org/
// Jos käytät json-editoria niin avaa data osoitteesta:
// http://appro.mit.jyu.fi/tiea2120/vt/vt3/data.json

"use strict";

window.onload = function () {
    document.querySelector('input[name="nimi"]').addEventListener("input", validateNimi);

    var leimaustapaBoxit = document.querySelectorAll('input[type="checkbox"]');
    for (let box of leimaustapaBoxit) {
        box.addEventListener("change", validateLeimaustapa);
        box.setCustomValidity("Valitse vähintään yksi leimaustapa.");
    }

    luoSarjaradio();

    for (var i = 0; i < 5; i++) {
        luoJasenInput(i);
    }

    var form = document.querySelector('form');
    form.addEventListener("submit", lisaaJoukkue);

    var joukkueLista = luoJoukkueLista();
    form.parentNode.appendChild(joukkueLista);
};

/*
 * ###################################
 * # Tietokantaa muokkaavat funktiot #
 * ###################################
 */

/**
 * @summary: Lisää tietorakenteeseen uuden joukkueen lomakkeeseen täytetyillä tiedoilla.
 * @param {Event} e: Lomakkeen submit-event
 */
function lisaaJoukkue(e) {
    e.preventDefault();
    var form = e.target;
    var nimi = form.querySelector('input[name="nimi"]').value.trim();
    var aika = form.querySelector('input[name="luontiaika"]').value;
    var leimaukset = form.querySelectorAll('input[type="checkbox"]');
    var sarjat = form.querySelectorAll('input[type="radio"]');
    var jasenInputs = document.getElementById("jasenetField").getElementsByTagName("input");
    //id on 16 numeroinen luku
    do {
        var id = Math.floor(Math.random() * Math.floor(10000000000000000));
        var duplicate = false;
        for (let i of data.joukkueet) {
            if (id === i.id) {
                duplicate = true;
            }
        }
    } while (duplicate);

    var joukkue = {
        nimi: nimi,
        jasenet: haeTaytetyt(jasenInputs),
        sarja: haeSarjaId(sarjat),
        seura: null,
        id: id,
        leimaustapa: haeValinnat(leimaukset),
        luontiaika: aika
    };
    console.log(joukkue);
    data.joukkueet.push(joukkue);
    console.log("Joukkue lisätty tietokantaan");
    var vanhalista = document.getElementById("joukkuelista");
    vanhalista.parentNode.replaceChild(luoJoukkueLista(), vanhalista);
    console.log(data);
    form.reset();
}

/**
 * @summary: Lisää valittujen checkboxien arvot taulukkoon ja palauttaa taulukon.
 * @param {NodeList} checkboxes: Läpikäytävät checkboxit
 * @returns {Array}: Valittujen checkboxien arvot
 */
function haeValinnat(checkboxes) {
    var valinnat = new Array;
    for (let i of checkboxes) {
        if (i.checked) {
            valinnat.push(i.value);
        }
    }
    return valinnat;
}

/**
 * @summary: Tutkii, mikä sarja on valittu ja palauttaa kyseisen sarjan id:n
 * @param {NodeList} valinnat: Sarjat -radionapit
 * @returns {int}: Valitun sarjan id
 */
function haeSarjaId(valinnat) {
    for (let valinta of valinnat) {
        if (valinta.checked) {
            for (let sarja of data.kisat[0].sarjat) {
                if (sarja.nimi === valinta.value) {
                    return sarja.id;
                }
            }
        }
    }
    console.error("Valittua sarjaa ei ole tietokannassa, mitäs ihmettä?");
}

/**
 * @summary: Lisää annettujen inputtien täytettyjen kenttien arvot palautettavaan taulukkoon.
 * @param {NodeList} inputs: Lista teksti-inputeista
 * @return {Array}: Teksti-kenttien epätyhjät arvot
 */
function haeTaytetyt(inputs) {
    var jasenet = new Array;
    for (let i of inputs) {
        if (i.value) {
            jasenet.push(i.value);
        }
    }
    return jasenet;
}

/*
 * ##################################
 * # DOM-Elementtien luomisfunktiot #
 * ##################################
 */

/**
 * @summary: Luo Sarja-radiobuttonit käyttäen tietokantaa.
 */
function luoSarjaradio() {
    var span = document.getElementById("sarja").firstElementChild;
    var sarjat = data.kisat[0].sarjat;
    var radiot = new Array();

    for (var i = 0; i < sarjat.length; i++) {
        var label = document.createElement('label');
        var txt = document.createTextNode(sarjat[i].nimi);
        var input = document.createElement('input');
        input.setAttribute('type', 'radio');
        input.setAttribute('value', sarjat[i].nimi);
        input.setAttribute('name', "sarja");

        label.appendChild(txt);
        label.appendChild(input);
        radiot.push(label);
    }
    radiot.sort(function (a, b) {
        return parseInt(a.lastChild.value) - parseInt(b.lastChild.value);
    });
    radiot[0].lastChild.checked = true;
    for (let i of radiot){
        span.appendChild(i);
    }
}

/**
 * @summary: Luo jäsen-inputin Jäsenet kohtaan.
 * @param {int} i: Montako jäsentä listassa on ennen lisäystä
 */
function luoJasenInput(i) {
    var jasenetField = document.getElementById("jasenetField");

    var label = document.createElement('label');
    var labelText = document.createTextNode("Jäsen " + (i + 1) + " ");

    var input = document.createElement("input");
    input.setAttribute('name', 'jasen' + (i + 1));
    input.setAttribute('type', 'text');
    input.setAttribute('size', '30');
    input.setCustomValidity("Jäseniä on oltava vähintään kaksi.");
    input.addEventListener("input", validateJasenet);

    label.appendChild(labelText);
    label.appendChild(input);

    jasenetField.appendChild(label);
}

/**
 * @summary: Luo DOM-elementtinä <ul></ul>-järjestämättömän listan joukkueista
 * @return {HTMLUListElement}: Lista kaikista joukkueista
 */
function luoJoukkueLista() {
    var ul1 = document.createElement('ul');
    ul1.setAttribute('id', 'joukkuelista');
    for (let i of data.joukkueet) {
        var li1 = document.createElement('li');
        var txt3 = document.createTextNode(i.nimi);
        ul1.appendChild(li1);
        li1.appendChild(txt3);
    }
    return ul1;
}

/*
 * #######################
 * # Validointi-funktiot #
 * #######################
 */

/**
 * @summary: Tarkistaa, että annettu nimi on uniikki
 * @param {Event} e: Nimi-kentän muutos
 */
function validateNimi(e) {
    var nimi = e.target.value.trim();
    for (let joukkue of data.joukkueet) {
        if (joukkue.nimi.trim() === nimi) {
            e.target.setCustomValidity("Syötetty joukkue on jo tietokannassa, anna eri nimi.");
            return;
        }
    }
    e.target.setCustomValidity("");
}

/**
 * @summary: Tarkistaa onko valittu vähintään yksi leimaustapa.
 * @param {Event} e: Checkboxin valinta.
 */
function validateLeimaustapa(e) {
    var count = 0;
    var leimaustapaBoxit = document.querySelectorAll('input[type="checkbox"]');
    for (let i of leimaustapaBoxit) {
        if (i.checked) {
            count++;
        }
    }
    if (count > 0) {
        for (let i of leimaustapaBoxit) {
            i.setCustomValidity("");
        }
    } else {
        for (let i of leimaustapaBoxit) {
            i.setCustomValidity("Valitse vähintään yksi leimaustapa.");
        }
    }
}

/**
 * @summary: Tarkistaa onko jäsenten nimet lisätty oikein.
 * @description: 1. Tarkistaa onko jäseniä lisätty vähintään kaksi, ja jos on, poistaa
 *               virheilmoituksen. Muuten tekee virheilmoituksen uudestaan.
 *               2. Tarkistaa onko kaikki input kentät täynnä ja luo uusia jos on.
 *               3. Jos viimeiset kaksi inputtia on tyhjiä, poistaa viimeisen, kunhan
 *               poisto ei vähennä input-kenttien määrää liikaa.
 * @param {Event} e: Jäsen-inputin tekstin muutos.
 */
function validateJasenet(e) {
    var inputs = document.getElementById("jasenetField").getElementsByTagName("input");

    //Lasketaan täytetyt inputit
    var count = 0;
    for (let input of inputs) {
        if (input.value) {
            count++;
        }
    }

    //Tarkistetaan että vähintään 2 inputtia on tehty.
    if (count < 2) {
        for (let input of inputs) {
            input.setCustomValidity("Jäseniä on oltava vähintään kaksi.");
        }
    } else {
        for (let input of inputs) {
            input.setCustomValidity("");
        }
    }

    //Tarkistetaan onko kaikki input-kentät täynnä ja luodaan uusi jos on
    if (inputs.length === count) {
        luoJasenInput(inputs.length);
    }

    //Tarkistetaan, voiko inputtien määrää vähentää ja vähennetään jos voi
    var vika = inputs[inputs.length - 1].value;
    var tokavika = inputs[inputs.length - 2].value;
    if (!vika && !tokavika && inputs.length > 5) {
        var jasenetField = document.getElementById("jasenetField");
        jasenetField.removeChild(jasenetField.lastElementChild);
    }
}