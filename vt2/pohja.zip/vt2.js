// data-muuttuja on sama kuin viikkotehtävässä 1.
//

"use strict";

console.log(data);

