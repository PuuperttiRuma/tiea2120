"use strict";

class App extends React.Component {
  constructor(props) {
    super(props);
    // Käytetään samaa tietorakennetta kuin viikkotehtävässä 1, mutta vain jäärogainin-
    // gin joukkueita. Tehdään tämän komponentin tilaan kopio jäärogainingin tiedoista.
    // Tee tehtävässä vaaditut lisäykset ja muutokset tämän komponentin tilaan. Tämä on
    // tehtävä näin, että saadaan oikeasti aikaan kopio eikä vain viittausta samaan
    // tietorakenteeseen. Objekteja ja taulukoita ei voida kopioida vain sijoitusope-
    // raattorilla. Päivitettäessä React-komponentin tilaa on aina vanha tila kopioitava
    // uudeksi tällä tavalla
    // kts. https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/from
    let kilpailu = new Object();
    kilpailu.nimi = data[2].nimi;
    kilpailu.loppuaika = data[2].loppuaika;
    kilpailu.alkuaika = data[2].alkuaika;
    kilpailu.kesto = data[2].kesto;
    kilpailu.leimaustapa = Array.from(data[2].leimaustapa);
    kilpailu.rastit = Array.from(data[2].rastit);
    function kopioi_joukkue(j) {
      let uusij = {};
      uusij.nimi = j.nimi;
      uusij.id = j.id;

      uusij["jasenet"] = Array.from(j["jasenet"]);
      uusij["rastit"] = Array.from(j["rastit"]);
      uusij["leimaustapa"] = Array.from(j["leimaustapa"]);
      return uusij;
    }
    function kopioi_sarja(s) {
      let uusis = {};
      uusis.nimi = s.nimi;
      uusis.alkuaika = s.alkuaika;
      uusis.loppuaika = s.loppuaika;
      uusis.kesto = s.kesto;
      uusis.joukkueet = Array.from(s.joukkueet, kopioi_joukkue);
      return uusis;
    }

    kilpailu.sarjat = Array.from(data[2].sarjat, kopioi_sarja);

    // tuhotaan vielä alkuperäisestä tietorakenteesta rastit ja joukkueet niin
    // varmistuuu, että kopiointi on onnistunut
    function purgeOrigData() {
      for (let i in data[2].rastit) {
        delete data[2].rastit[i];
      }
      for (let sarja of data[2].sarjat) {
        for (let i in sarja.joukkueet) {
          delete sarja.joukkueet[i];
        }
      }
    }
    purgeOrigData();
    //console.log(kilpailu);
    //console.log(data);

    this.state = {
       kilpailu: kilpailu,
       joukkueet: this.luoJoukkueLista(kilpailu.sarjat)
    };
    return;
  } 

  updateData = (newJoukkue, newSarja) => {
    if (newJoukkue.id === "") newJoukkue.id.luoID;
    let newKilpailu = this.deepcopyKilpailu();
    for (let sarja of newKilpailu.sarjat){
      if (sarja.nimi === newSarja) sarja.joukkueet.push(newJoukkue);
    }    
    console.log(newKilpailu);
    this.setState({
      kilpailu: newKilpailu,
      joukkueet: this.luoJoukkueLista(newKilpailu.sarjat)
    })  
  }

  //#region Apufunktiot

  deepcopyKilpailu(){
    const kilpailu = this.state.kilpailu;
    let newKilpailu = new Object();
    newKilpailu.nimi = kilpailu.nimi;
    newKilpailu.loppuaika = kilpailu.loppuaika;
    newKilpailu.alkuaika = kilpailu.alkuaika;
    newKilpailu.kesto = kilpailu.kesto;
    newKilpailu.leimaustapa = Array.from(kilpailu.leimaustapa);
    newKilpailu.rastit = Array.from(kilpailu.rastit);
    function kopioi_joukkue(j) {
      let uusij = {};
      uusij.nimi = j.nimi;
      uusij.id = j.id;

      uusij["jasenet"] = Array.from(j["jasenet"]);
      uusij["rastit"] = Array.from(j["rastit"]);
      uusij["leimaustapa"] = Array.from(j["leimaustapa"]);
      return uusij;
    }
    function kopioi_sarja(s) {
      let uusis = {};
      uusis.nimi = s.nimi;
      uusis.alkuaika = s.alkuaika;
      uusis.loppuaika = s.loppuaika;
      uusis.kesto = s.kesto;
      uusis.joukkueet = Array.from(s.joukkueet, kopioi_joukkue);
      return uusis;
    }
    newKilpailu.sarjat = Array.from(kilpailu.sarjat, kopioi_sarja);
    return newKilpailu;
  }

  /**
   * @summary: Luo uniikin ID-numeron.
   * @returns {int}: Uniikki 16-numeroinen ID-numero jota ei löydy tietokannasta
   */
  luoID() {
    let id = Math.floor(Math.random() * Math.floor(10000000000000000));
    do {
      var unique = false; //Pitää olla var, jotta pääsee käsiksi for-loopissa
      unique = this.onUniikkiID(id, this.state.kilpailu.rastit);
      for (let sarja of this.state.kilpailu.sarjat) {
        unique = this.onUniikkiID(id, sarja.joukkueet);
      }
    } while (!unique);
    return id;
  }

  /**
  * @summary: Tarkistaa, että annettua ID:tä ei löydy annetusta datasta.
  * @param {int} id: 16-numeroinen tarkastettava ID-numero
  * @param {JSON} iterable: Iteroitavaa JSON-dataa joka tarkistetaan.
  * @return {boolean}: Tosi jos ID on uniikki, epätosi jos löytyy sama ID-numero
  */
  onUniikkiID(id, iterable) {
    for (let i of iterable) {
      if (id === i.id) {
        return false;
      }
    }
    return true;
  }

  luoJoukkueLista (sarjat){
    let joukkueet = [];
    for (let sarja of sarjat){
      for (let joukkue of sarja.joukkueet){
        joukkueet.push(joukkue);
      }
    }
    joukkueet.sort((a,b) => {
      const nameA = a.nimi.toUpperCase();
      const nameB = b.nimi.toUpperCase();
      if (nameA < nameB) return -1;
      if (nameA > nameB) return 1;
      return 0;
    });
    return joukkueet;
}

  //#endregion

  render() {

    return (
      <div className="ylin">
        <LisaaJoukkue updateData={this.updateData} />
        <ListaaJoukkueet joukkueet={this.state.joukkueet} />
      </div>
    )
  }
}

function ListaaJoukkueet(props){
    return (
      <div className="joukkueListaus">
        <h1>Joukkueet</h1>
        <ul>
          {props.joukkueet.map((joukkue, i) => {
            return (
              <li key={joukkue.nimi}>
                {joukkue.nimi}
              </li>
            );
          })}
        </ul>
      </div>
    )
}

class LisaaJoukkue extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      sarja: "",
      id: "",
      jasenet: ["","","","",""],
      nimi: "",
      leimaustapa: [],
      rastit: [],
    }
  }

  handleSubmit = e => {
    e.preventDefault();
    const {id, jasenet, leimaustapa, nimi, rastit, sarja} = this.state;
    const newJoukkue = {
      id: id,
      jasenet: jasenet,
      leimaustapa: leimaustapa,
      nimi: nimi,
      rastit: rastit
    }
    this.props.updateData(newJoukkue, sarja);

    //Tyhjennetään lomakkeen tila ja validaatiot
    this.setState({
      sarja: "2h",
      id: "",
      jasenet: ["","","","",""],
      leimaustapa: "",
      nimi: "",
      rastit: []
    });
    validateJoukkueNimi("");
    validateLeimaustapa([]);
    validateJasenet(["","","","",""]);
  }

  handleChange(e) {
    const { name, value, id, checked } = e.target;
    let newValue;
    switch (name) {
      case "nimi":
        newValue = value;
        validateJoukkueNimi(newValue);
        break;

      case "jasenet":
        newValue = this.state.jasenet.map((jasen, i) => {
          if (id === ("jasen" + i)) jasen = value;
          return jasen;
        });
        validateJasenet(newValue);
        break;

      case "leimaustapa":
        checked
          ? newValue = this.state.leimaustapa.concat(value)
          : newValue = this.state.leimaustapa.filter(word => word !== value)
        validateLeimaustapa(newValue);
        break;

      default:
        newValue = value;
        break;
    }
    this.setState({
      [name]: newValue
    })
  }

  componentDidMount() {
    validateJoukkueNimi(this.state.nimi);
    this.setState({
      sarja: "2h"
    });
    validateLeimaustapa(this.state.leimaustapa);
    validateJasenet(this.state.jasenet);
  }

  render() {
    return (
      <form onSubmit={e => this.handleSubmit(e)}>
        <h1>Lisää joukkue</h1>
        <fieldset><legend>Joukkueen tiedot</legend>

          <NimiField
            value={this.state.nimi}
            handleChange={(e) => this.handleChange(e)}
          />
          <LeimaustavatField
            leimausState={this.state.leimaustapa}
            handleChange={(e) => this.handleChange(e)}
          />
          <SarjaField
            sarjaState={this.state.sarja}
            handleChange={(e) => this.handleChange(e)}
          />
        </fieldset>

        <fieldset><legend>Jäsenet</legend>
          <JasenetField
            jasenet={this.state.jasenet}
            handleChange={e => this.handleChange(e)}
          />
        </fieldset>

        <button>Tallenna</button>
      </form>
    )
  }
}

//#region Input Components
function NimiField(props) {
  return (
    <div className="input-div">
      <label>Nimi</label>
      <input
        id="joukkueNimi"
        type="text"
        name="nimi"
        value={props.value}
        onChange={props.handleChange}
      />
    </div>)
}

function LeimaustavatField(props) {
  const leimaustavat = ["GPS", "NFX", "QR", "Lomake"];
  return (
    <div className="input-div">
      <label>Leimaustapa</label>
      <ul id="leimaustavat">

        {leimaustavat.map((val, i) => {
          return (
            <li key={val}>
              <label>{val}
                <input
                  type="checkbox"
                  name="leimaustapa"
                  value={val}
                  checked={props.leimausState.includes(val)}
                  id={val}
                  onChange={props.handleChange}
                />
              </label>
            </li>
          );
        })}

      </ul>
    </div>
  )
}

function SarjaField(props) {
  const sarjat = ["2h", "4h", "8h"];
  return (
    <div className="input-div">
      <label>Sarja</label>
      <ul>
        {sarjat.map((val, i) => {
          return (
            <li key={val}>
              <label>{val}
                <input
                  type="radio"
                  name="sarja"
                  value={val}
                  checked={props.sarjaState === val}
                  id={val}
                  onChange={props.handleChange}
                />
              </label>
            </li>
          );
        })}
      </ul>
    </div>
  )
}

function JasenetField(props) {
  return (
    <div>
      {props.jasenet.map((val, i) => {
        return (
          <div className="input-div" key={"jasen" + (i + 1)}>
            <label>{"Jäsen " + (i + 1)}</label>
            <input
              id={"jasen" + (i)}
              type="text"
              value={val}
              name="jasenet"
              onChange={props.handleChange}
            />
          </div>
        );
      })}
    </div>
  )
}
//#endregion

//#region Validation Functions

function validateJoukkueNimi(nimi) {
  let message = "";
  if (nimi.trim() === "") message = "Joukkueella on oltava nimi!";
  $("#joukkueNimi")[0].setCustomValidity(message);
};

function validateLeimaustapa(leimaustapa) {
  let message = "";
  if (leimaustapa.length === 0) message = "Oltava vähintään yksi leimaustapa!";
  $("#GPS")[0].setCustomValidity(message);
}

function validateJasenet(jasenet) {
  let message = "";
  let jasenia = 0;
  for (let jasen of jasenet) {
    if (jasen.trim() !== "") jasenia++;
  }
  if (jasenia < 2) message = "Joukkueessa oltava vähintään 2 kilpailijaa!";
  $("#jasen0")[0].setCustomValidity(message);
}
//#endregion



ReactDOM.render(
  <App />,
  document.getElementById('root')

);
