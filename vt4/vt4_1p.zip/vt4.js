window.onload = function () {
    window.addEventListener("resize", paivitaKoot);
    //luodaan liikkuvat neonpalkit
    piirraPuput();
    for (let i = 0; i < 10; i++) {
        timeoutID = window.setTimeout(luoNeonpalkki, 350*i);
    }

}

function piirraPuput() {
    var body = document.querySelector("body");
    var img = document.getElementById("pupu");
    var puolivali = parseInt(img.naturalWidth) / 2;
    var korkeus = parseInt(img.naturalHeight);

    var vasen = luoCanvas(puolivali, korkeus, "pupu-vasen");
    var oikea = luoCanvas(puolivali, korkeus, "pupu-oikea");
    body.appendChild(vasen);
    body.appendChild(oikea);

    var vasenCtx = vasen.getContext('2d');
    var oikeaCtx = oikea.getContext('2d');

    vasenCtx.drawImage(img, 0, 0, puolivali, korkeus, 0, 0, puolivali, korkeus);

    oikeaCtx.save();
    oikeaCtx.translate(puolivali,0)
    oikeaCtx.scale(-1, 1);
    oikeaCtx.drawImage(img, 0, 0, puolivali, korkeus, 0, 0, puolivali, korkeus);
    oikeaCtx.restore();
}

/**
 * @summary: Luo canvas-elementin annetuilla arvoilla ja palauttaa sen
 * @param {int} leveys: canvaksen haluttu leveys integerin� tai stringin�
 * @param {int} korkeus: canvaksen haluttu korkeus integerin� tai stringin�
 * @param {string} id: Canvaksen id
 * @return {canvas}: Luotu Canvas-elementti
 */
function luoCanvas(leveys, korkeus, id) {
    var canvas = document.createElement("canvas");
    canvas.setAttribute("width", parseInt(leveys));
    canvas.setAttribute("height", parseInt(korkeus));
    canvas.setAttribute("id", id);
    return canvas;
}

function luoNeonpalkki() {
    let svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    let rect = document.createElementNS("http://www.w3.org/2000/svg", "rect");
    svg.appendChild(rect);
    svg.setAttribute("class", "neonpalkki");
    svg.setAttribute("version", "1.1.");
    svg.setAttribute("xmlns", "http://www.w3.org/2000/svg");
    svg.setAttribute("width", "100");
    svg.setAttribute("height", window.innerHeight);

    rect.setAttribute("x", "0");
    rect.setAttribute("y", "0");
    rect.setAttribute("width", "100");
    rect.setAttribute("height", "100%");
    rect.setAttribute("fill", "green");

    document.querySelector("body").appendChild(svg);
}

function paivitaKoot() {
    svgs = document.querySelectorAll("svg");
    for (let svg of svgs) {
        svg.setAttribute("height", window.innerHeight);
    }
}